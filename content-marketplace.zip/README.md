# Secret Fans - Plataforma de Conteúdo Exclusivo

Uma plataforma moderna para criadores de conteúdo adulto monetizarem seu trabalho de forma segura e privada.

## 🚀 Deploy para Produção

### Opções de Hospedagem Recomendadas:

#### 1. **Vercel (Recomendado)**
\`\`\`bash
# Instalar Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
\`\`\`

#### 2. **Netlify**
\`\`\`bash
# Build do projeto
npm run build

# Upload da pasta 'out' para Netlify
\`\`\`

#### 3. **Hospedagem Tradicional (cPanel/FTP)**
\`\`\`bash
# Build estático
npm run build

# Upload da pasta 'out' para public_html
\`\`\`

## 📋 Configurações de Produção

### Variáveis de Ambiente Necessárias:
\`\`\`env
NEXT_PUBLIC_SITE_URL=https://seudominio.com
NEXT_PUBLIC_APP_NAME=Secret Fans
\`\`\`

### Recursos da Plataforma:
- ✅ Sistema de autenticação mock
- ✅ Dashboard diferenciado (Criadores vs Assinantes)
- ✅ Feed social com interações
- ✅ Sistema de chat privado
- ✅ Transmissões ao vivo
- ✅ Upload de conteúdo
- ✅ Sistema de pagamentos (interface)
- ✅ Design responsivo
- ✅ Otimizado para SEO

### Contas de Teste:
- **Criador**: admin@admin.com / admin123
- **Assinante**: buyer@test.com / test123

## 🛠️ Tecnologias Utilizadas
- Next.js 14
- React 19
- TypeScript
- Tailwind CSS v4
- Radix UI
- Lucide Icons

## 📱 Compatibilidade
- ✅ Desktop
- ✅ Tablet
- ✅ Mobile
- ✅ PWA Ready

---

**Secret Fans** - Seus segredos mais íntimos, sua plataforma mais segura.
