"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Upload, X, ImageIcon, Video, DollarSign, Eye, Lock, Plus, FileText } from "lucide-react"
import { useDropzone } from "react-dropzone"

interface UploadedFile {
  id: string
  file: File
  preview: string
  type: "image" | "video"
  progress: number
  uploaded: boolean
}

export default function UploadPage() {
  const [files, setFiles] = useState<UploadedFile[]>([])
  const [contentData, setContentData] = useState({
    title: "",
    description: "",
    price: "",
    category: "",
    tags: "",
    isExclusive: false,
  })
  const [isUploading, setIsUploading] = useState(false)

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles: UploadedFile[] = acceptedFiles.map((file) => ({
      id: Math.random().toString(36).substr(2, 9),
      file,
      preview: URL.createObjectURL(file),
      type: file.type.startsWith("image/") ? "image" : "video",
      progress: 0,
      uploaded: false,
    }))
    setFiles((prev) => [...prev, ...newFiles])
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "image/*": [".jpeg", ".jpg", ".png", ".gif", ".webp"],
      "video/*": [".mp4", ".mov", ".avi", ".mkv", ".webm"],
    },
    maxSize: 100 * 1024 * 1024, // 100MB
  })

  const removeFile = (id: string) => {
    setFiles((prev) => prev.filter((file) => file.id !== id))
  }

  const simulateUpload = (fileId: string) => {
    const interval = setInterval(() => {
      setFiles((prev) =>
        prev.map((file) => {
          if (file.id === fileId) {
            const newProgress = Math.min(file.progress + 10, 100)
            return {
              ...file,
              progress: newProgress,
              uploaded: newProgress === 100,
            }
          }
          return file
        }),
      )
    }, 200)

    setTimeout(() => {
      clearInterval(interval)
    }, 2000)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (files.length === 0) {
      alert("Adicione pelo menos um arquivo")
      return
    }

    setIsUploading(true)

    // Simulate upload for all files
    files.forEach((file) => {
      if (!file.uploaded) {
        simulateUpload(file.id)
      }
    })

    // Simulate content creation
    setTimeout(() => {
      setIsUploading(false)
      alert("Conteúdo publicado com sucesso!")
      // Reset form
      setFiles([])
      setContentData({
        title: "",
        description: "",
        price: "",
        category: "",
        tags: "",
        isExclusive: false,
      })
    }, 3000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Upload de Conteúdo</h1>
            <Button variant="outline" onClick={() => window.history.back()}>
              Voltar
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* File Upload Area */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="w-5 h-5" />
                  Arquivos de Mídia
                </CardTitle>
                <CardDescription>Faça upload de suas fotos e vídeos. Máximo 100MB por arquivo.</CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  {...getRootProps()}
                  className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                    isDragActive
                      ? "border-purple-500 bg-purple-50 dark:bg-purple-900/20"
                      : "border-slate-300 hover:border-purple-400 dark:border-slate-600"
                  }`}
                >
                  <input {...getInputProps()} />
                  <div className="flex flex-col items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
                      <Plus className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <p className="text-lg font-medium text-slate-900 dark:text-white">
                        {isDragActive ? "Solte os arquivos aqui" : "Arraste arquivos ou clique para selecionar"}
                      </p>
                      <p className="text-sm text-slate-500 mt-1">Suporte para JPG, PNG, GIF, MP4, MOV (máx. 100MB)</p>
                    </div>
                  </div>
                </div>

                {/* File Preview */}
                {files.length > 0 && (
                  <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {files.map((file) => (
                      <div key={file.id} className="relative group">
                        <div className="aspect-square rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-800">
                          {file.type === "image" ? (
                            <img
                              src={file.preview || "/placeholder.svg"}
                              alt="Preview"
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Video className="w-12 h-12 text-slate-400" />
                            </div>
                          )}

                          {/* Upload Progress */}
                          {file.progress > 0 && file.progress < 100 && (
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                              <div className="w-3/4">
                                <Progress value={file.progress} className="h-2" />
                                <p className="text-white text-sm text-center mt-2">{file.progress}%</p>
                              </div>
                            </div>
                          )}

                          {/* Success Badge */}
                          {file.uploaded && (
                            <div className="absolute top-2 left-2">
                              <Badge className="bg-green-500 text-white">Enviado</Badge>
                            </div>
                          )}
                        </div>

                        {/* File Info */}
                        <div className="mt-2 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {file.type === "image" ? (
                              <ImageIcon className="w-4 h-4 text-slate-500" />
                            ) : (
                              <Video className="w-4 h-4 text-slate-500" />
                            )}
                            <span className="text-sm text-slate-600 dark:text-slate-400 truncate">
                              {file.file.name}
                            </span>
                          </div>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeFile(file.id)}
                            className="opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Content Details */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Detalhes do Conteúdo
                </CardTitle>
                <CardDescription>Adicione informações sobre seu conteúdo para atrair mais compradores.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Título *</Label>
                    <Input
                      id="title"
                      placeholder="Título atrativo para seu conteúdo"
                      value={contentData.title}
                      onChange={(e) => setContentData({ ...contentData, title: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Categoria *</Label>
                    <Select
                      value={contentData.category}
                      onValueChange={(value) => setContentData({ ...contentData, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="photography">Fotografia</SelectItem>
                        <SelectItem value="art">Arte Digital</SelectItem>
                        <SelectItem value="lifestyle">Lifestyle</SelectItem>
                        <SelectItem value="fitness">Fitness</SelectItem>
                        <SelectItem value="fashion">Moda</SelectItem>
                        <SelectItem value="travel">Viagem</SelectItem>
                        <SelectItem value="other">Outros</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    placeholder="Descreva seu conteúdo, o que torna ele especial..."
                    rows={4}
                    value={contentData.description}
                    onChange={(e) => setContentData({ ...contentData, description: e.target.value })}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="price">Preço (R$) *</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <Input
                        id="price"
                        type="number"
                        placeholder="0.00"
                        min="0"
                        step="0.01"
                        className="pl-10"
                        value={contentData.price}
                        onChange={(e) => setContentData({ ...contentData, price: e.target.value })}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tags">Tags</Label>
                    <Input
                      id="tags"
                      placeholder="arte, digital, exclusivo (separadas por vírgula)"
                      value={contentData.tags}
                      onChange={(e) => setContentData({ ...contentData, tags: e.target.value })}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Visibility Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-5 h-5" />
                  Configurações de Visibilidade
                </CardTitle>
                <CardDescription>Defina quem pode ver e comprar seu conteúdo.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Lock className="w-5 h-5 text-slate-500" />
                    <div>
                      <p className="font-medium">Conteúdo Exclusivo</p>
                      <p className="text-sm text-slate-500">Apenas assinantes premium podem ver</p>
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant={contentData.isExclusive ? "default" : "outline"}
                    onClick={() => setContentData({ ...contentData, isExclusive: !contentData.isExclusive })}
                  >
                    {contentData.isExclusive ? "Ativado" : "Desativado"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Submit Button */}
            <div className="flex justify-end gap-4">
              <Button type="button" variant="outline">
                Salvar Rascunho
              </Button>
              <Button
                type="submit"
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                disabled={isUploading || files.length === 0}
              >
                {isUploading ? "Publicando..." : "Publicar Conteúdo"}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
