"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Search,
  Heart,
  MessageCircle,
  Share2,
  Play,
  ImageIcon,
  Video,
  Star,
  Send,
  MoreHorizontal,
  Bookmark,
  Radio,
  Users,
  Lock,
} from "lucide-react"

const mockPosts = [
  {
    id: 1,
    creator: "Sophia Sensual",
    creatorAvatar: "/abstract-profile.png",
    creatorVerified: true,
    content: "Nova sessão de fotos íntimas acabou de sair! 🔥 Quem quer ver o que aconteceu nos bastidores? 😈",
    preview: "Prévia exclusiva da minha nova sessão...",
    media: {
      type: "image",
      thumbnail: "/placeholder-g0tk3.png",
      isBlurred: true,
      price: 25.0,
    },
    likes: 234,
    comments: 45,
    shares: 12,
    timestamp: "2h",
    isLive: false,
    category: "Fotos Íntimas",
  },
  {
    id: 2,
    creator: "Isabella Fire",
    creatorAvatar: "/abstract-profile.png",
    creatorVerified: true,
    content: "AO VIVO AGORA! 🔴 Sessão especial para meus assinantes VIP... não percam! 💋",
    preview: "Live exclusiva acontecendo agora...",
    media: {
      type: "live",
      thumbnail: "/makeup-tutorial.png",
      isBlurred: false,
      viewers: 127,
    },
    likes: 456,
    comments: 89,
    shares: 23,
    timestamp: "Ao vivo",
    isLive: true,
    category: "Live Adulto",
  },
  {
    id: 3,
    creator: "Valentina Secret",
    creatorAvatar: "/abstract-profile.png",
    creatorVerified: true,
    content: "Vídeo completo da minha noite especial... 🌙 Só para maiores de 18! Quem quer assistir? 🔞",
    preview: "Conteúdo exclusivo +18...",
    media: {
      type: "video",
      thumbnail: "/home-workout.png",
      isBlurred: true,
      price: 45.0,
      duration: "15:30",
    },
    likes: 678,
    comments: 123,
    shares: 34,
    timestamp: "4h",
    isLive: false,
    category: "Vídeos Íntimos",
  },
  {
    id: 4,
    creator: "Luna Desire",
    creatorAvatar: "/abstract-profile.png",
    creatorVerified: true,
    content: "Ensaio sensual na banheira... 🛁 Água quente e muito vapor! Quem quer se juntar? 💦",
    preview: "Ensaio sensual exclusivo...",
    media: {
      type: "image",
      thumbnail: "/placeholder-v5wyo.png",
      isBlurred: true,
      price: 30.0,
    },
    likes: 345,
    comments: 67,
    shares: 18,
    timestamp: "6h",
    isLive: false,
    category: "Ensaios Sensuais",
  },
]

export default function ExplorePage() {
  const [newComment, setNewComment] = useState("")
  const [activeComments, setActiveComments] = useState<{ [key: number]: boolean }>({})

  const toggleComments = (postId: number) => {
    setActiveComments((prev) => ({
      ...prev,
      [postId]: !prev[postId],
    }))
  }

  const handleLike = (postId: number) => {
    // Handle like functionality
    console.log("[v0] Liked post:", postId)
  }

  const handleShare = (postId: number) => {
    // Handle share functionality
    console.log("[v0] Shared post:", postId)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-white dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/90 backdrop-blur-sm dark:bg-slate-900/90 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center">
                <Heart className="w-4 h-4 text-white fill-white" />
              </div>
              <span className="text-xl font-bold text-slate-900 dark:text-white">Secret Fans</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/explore" className="text-red-600 font-medium flex items-center">
                <Heart className="w-4 h-4 mr-1" />
                Feed
              </Link>
              <Link href="/live" className="text-slate-600 hover:text-red-600 dark:text-slate-300 flex items-center">
                <Radio className="w-4 h-4 mr-1" />
                Lives
              </Link>
              <Link href="/creators" className="text-slate-600 hover:text-red-600 dark:text-slate-300">
                Criadores
              </Link>
              <Link href="/chat" className="text-slate-600 hover:text-red-600 dark:text-slate-300 flex items-center">
                <MessageCircle className="w-4 h-4 mr-1" />
                Chat
              </Link>
            </nav>
            <div className="flex items-center space-x-3">
              <Link href="/login">
                <Button variant="ghost" className="text-slate-700 hover:text-red-600 dark:text-slate-200">
                  Entrar
                </Button>
              </Link>
              <Link href="/register">
                <Button className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white">
                  Começar
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 max-w-2xl">
        {/* Page Header */}
        <div className="mb-6 text-center">
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Feed Secreto 🔥</h1>
          <p className="text-slate-600 dark:text-slate-300">Conteúdo exclusivo dos seus criadores favoritos</p>
        </div>

        {/* Search Bar */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Buscar criadores ou conteúdo..."
              className="pl-10 bg-white dark:bg-slate-800 border-red-200 focus:border-red-500"
            />
          </div>
        </div>

        {/* Feed Posts */}
        <div className="space-y-6">
          {mockPosts.map((post) => (
            <Card key={post.id} className="bg-white dark:bg-slate-800 border-red-100 dark:border-slate-700">
              <CardContent className="p-0">
                {/* Post Header */}
                <div className="p-4 pb-0">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-10 h-10 ring-2 ring-red-200">
                        <AvatarImage src={post.creatorAvatar || "/placeholder.svg"} />
                        <AvatarFallback className="bg-red-100 text-red-600">{post.creator.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center space-x-1">
                          <span className="font-semibold text-slate-900 dark:text-white">{post.creator}</span>
                          {post.creatorVerified && <Star className="w-4 h-4 text-red-500 fill-red-500" />}
                          {post.isLive && (
                            <Badge className="bg-red-600 text-white text-xs ml-2">
                              <Radio className="w-3 h-3 mr-1" />
                              AO VIVO
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center space-x-2 text-sm text-slate-500">
                          <span>{post.timestamp}</span>
                          <span>•</span>
                          <Badge variant="secondary" className="text-xs">
                            {post.category}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Post Content */}
                <div className="px-4 py-2">
                  <p className="text-slate-900 dark:text-white">{post.content}</p>
                </div>

                {/* Media Content */}
                <div className="relative">
                  <div className="aspect-[4/3] bg-slate-100 dark:bg-slate-700 relative overflow-hidden">
                    <img
                      src={post.media.thumbnail || "/placeholder.svg"}
                      alt="Post media"
                      className={`w-full h-full object-cover ${post.media.isBlurred ? "blur-md" : ""}`}
                    />

                    {/* Media Overlay */}
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      {post.media.type === "live" ? (
                        <div className="text-center text-white">
                          <Radio className="w-12 h-12 mx-auto mb-2 text-red-500" />
                          <p className="font-semibold">AO VIVO</p>
                          <p className="text-sm flex items-center justify-center">
                            <Users className="w-4 h-4 mr-1" />
                            {post.media.viewers} assistindo
                          </p>
                        </div>
                      ) : post.media.isBlurred ? (
                        <div className="text-center text-white">
                          <Lock className="w-12 h-12 mx-auto mb-2" />
                          <p className="font-semibold">Conteúdo Exclusivo</p>
                          <p className="text-sm">R$ {post.media.price?.toFixed(2)}</p>
                          <Button className="mt-2 bg-red-600 hover:bg-red-700 text-white">Desbloquear</Button>
                        </div>
                      ) : (
                        <div className="text-center text-white">
                          <Play className="w-12 h-12 mx-auto mb-2" />
                          {post.media.duration && <p className="text-sm">{post.media.duration}</p>}
                        </div>
                      )}
                    </div>

                    {/* Media Type Badge */}
                    <div className="absolute top-3 left-3">
                      <Badge className="bg-black/70 text-white">
                        {post.media.type === "image" && <ImageIcon className="w-3 h-3 mr-1" />}
                        {post.media.type === "video" && <Video className="w-3 h-3 mr-1" />}
                        {post.media.type === "live" && <Radio className="w-3 h-3 mr-1" />}
                        {post.media.type === "image" ? "Foto" : post.media.type === "video" ? "Vídeo" : "Live"}
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* Post Actions */}
                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleLike(post.id)}
                        className="flex items-center space-x-1 text-slate-600 hover:text-red-600"
                      >
                        <Heart className="w-5 h-5" />
                        <span>{post.likes}</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleComments(post.id)}
                        className="flex items-center space-x-1 text-slate-600 hover:text-red-600"
                      >
                        <MessageCircle className="w-5 h-5" />
                        <span>{post.comments}</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleShare(post.id)}
                        className="flex items-center space-x-1 text-slate-600 hover:text-red-600"
                      >
                        <Share2 className="w-5 h-5" />
                        <span>{post.shares}</span>
                      </Button>
                    </div>
                    <Button variant="ghost" size="sm" className="text-slate-600 hover:text-red-600">
                      <Bookmark className="w-5 h-5" />
                    </Button>
                  </div>

                  {/* Comments Section */}
                  {activeComments[post.id] && (
                    <div className="border-t pt-3 space-y-3">
                      {/* Sample Comments */}
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <Avatar className="w-6 h-6">
                            <AvatarFallback className="bg-red-100 text-red-600 text-xs">U</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <p className="text-sm">
                              <span className="font-semibold">user123</span> Incrível! 🔥
                            </p>
                            <p className="text-xs text-slate-500">2h</p>
                          </div>
                        </div>
                        <div className="flex items-start space-x-2">
                          <Avatar className="w-6 h-6">
                            <AvatarFallback className="bg-red-100 text-red-600 text-xs">F</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <p className="text-sm">
                              <span className="font-semibold">fan_secreto</span> Quando vai ter mais? 😍
                            </p>
                            <p className="text-xs text-slate-500">1h</p>
                          </div>
                        </div>
                      </div>

                      {/* Comment Input */}
                      <div className="flex items-center space-x-2">
                        <Avatar className="w-6 h-6">
                          <AvatarFallback className="bg-red-100 text-red-600 text-xs">V</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 flex items-center space-x-2">
                          <Input
                            placeholder="Adicione um comentário..."
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            className="flex-1 text-sm"
                          />
                          <Button size="sm" className="bg-red-600 hover:bg-red-700 text-white">
                            <Send className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-8">
          <Button
            variant="outline"
            size="lg"
            className="border-red-200 text-red-600 hover:bg-red-50 dark:border-red-800 dark:text-red-400 bg-transparent"
          >
            Carregar Mais Posts
          </Button>
        </div>
      </div>
    </div>
  )
}
