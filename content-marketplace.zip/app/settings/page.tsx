"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import {
  Settings,
  User,
  Bell,
  Shield,
  CreditCard,
  HelpCircle,
  LogOut,
  Play,
  ArrowLeft,
  Download,
  Trash2,
} from "lucide-react"

export default function SettingsPage() {
  const [darkMode, setDarkMode] = useState(false)
  const [language, setLanguage] = useState("pt-BR")
  const [autoDownload, setAutoDownload] = useState(true)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/dashboard" className="flex items-center space-x-2 text-slate-600 hover:text-slate-900">
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar ao Dashboard</span>
            </Link>
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Play className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-bold text-slate-900 dark:text-white">ContentHub</span>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Configurações</h1>
            <p className="text-slate-600 dark:text-slate-300">Gerencie suas preferências e configurações da conta</p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            {/* Settings Navigation */}
            <div className="lg:col-span-1">
              <Card>
                <CardContent className="p-4">
                  <nav className="space-y-2">
                    <Link
                      href="/profile"
                      className="flex items-center space-x-3 p-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <User className="w-4 h-4" />
                      <span>Perfil</span>
                    </Link>
                    <Link
                      href="/settings"
                      className="flex items-center space-x-3 p-3 rounded-lg bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300"
                    >
                      <Settings className="w-4 h-4" />
                      <span>Geral</span>
                    </Link>
                    <Link
                      href="/profile#notifications"
                      className="flex items-center space-x-3 p-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <Bell className="w-4 h-4" />
                      <span>Notificações</span>
                    </Link>
                    <Link
                      href="/profile#security"
                      className="flex items-center space-x-3 p-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <Shield className="w-4 h-4" />
                      <span>Segurança</span>
                    </Link>
                    <Link
                      href="/profile#billing"
                      className="flex items-center space-x-3 p-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <CreditCard className="w-4 h-4" />
                      <span>Pagamentos</span>
                    </Link>
                  </nav>
                </CardContent>
              </Card>
            </div>

            {/* Settings Content */}
            <div className="lg:col-span-3 space-y-6">
              {/* Appearance */}
              <Card>
                <CardHeader>
                  <CardTitle>Aparência</CardTitle>
                  <CardDescription>Personalize a aparência da plataforma</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Modo Escuro</Label>
                      <p className="text-sm text-slate-500">Ative o tema escuro para reduzir o cansaço visual</p>
                    </div>
                    <Switch checked={darkMode} onCheckedChange={setDarkMode} />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Idioma</Label>
                      <p className="text-sm text-slate-500">Escolha o idioma da interface</p>
                    </div>
                    <Badge variant="outline">Português (BR)</Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Content Preferences */}
              <Card>
                <CardHeader>
                  <CardTitle>Preferências de Conteúdo</CardTitle>
                  <CardDescription>Configure como você interage com o conteúdo</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Download Automático</Label>
                      <p className="text-sm text-slate-500">Baixe automaticamente conteúdo comprado</p>
                    </div>
                    <Switch checked={autoDownload} onCheckedChange={setAutoDownload} />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Qualidade de Vídeo</Label>
                      <p className="text-sm text-slate-500">Qualidade padrão para reprodução de vídeos</p>
                    </div>
                    <Badge variant="outline">HD (720p)</Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Data & Storage */}
              <Card>
                <CardHeader>
                  <CardTitle>Dados e Armazenamento</CardTitle>
                  <CardDescription>Gerencie seus dados e uso de armazenamento</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Espaço Utilizado</Label>
                      <p className="text-sm text-slate-500">2.4 GB de 10 GB utilizados</p>
                    </div>
                    <div className="w-32 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div className="w-1/4 h-full bg-gradient-to-r from-purple-600 to-blue-600"></div>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Limpar Cache</Label>
                      <p className="text-sm text-slate-500">Remove arquivos temporários para liberar espaço</p>
                    </div>
                    <Button variant="outline" size="sm">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Limpar
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Account Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Ações da Conta</CardTitle>
                  <CardDescription>Opções avançadas para sua conta</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Exportar Dados</Label>
                      <p className="text-sm text-slate-500">Baixe uma cópia de todos os seus dados</p>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Exportar
                    </Button>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Suporte</Label>
                      <p className="text-sm text-slate-500">Precisa de ajuda? Entre em contato conosco</p>
                    </div>
                    <Button variant="outline" size="sm">
                      <HelpCircle className="w-4 h-4 mr-2" />
                      Ajuda
                    </Button>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-red-600">Sair da Conta</Label>
                      <p className="text-sm text-slate-500">Desconecte-se de todos os dispositivos</p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-red-600 border-red-200 hover:bg-red-50 bg-transparent"
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      Sair
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
