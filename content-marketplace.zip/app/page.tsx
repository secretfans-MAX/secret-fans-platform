"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, DollarSign, Users, Shield, Lock, LogOut } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"

export default function HomePage() {
  const { user, logout } = useAuth()

  const handleLogout = () => {
    logout()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-red-50 dark:from-slate-900 dark:to-red-950">
      {/* Header */}
      <header className="border-b bg-white/90 backdrop-blur-sm dark:bg-slate-900/90 border-red-100 dark:border-red-900">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center">
              <Heart className="w-4 h-4 text-white fill-white" />
            </div>
            <span className="text-xl font-bold text-slate-900 dark:text-white">Secret Fans</span>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <Link
              href="/explore"
              className="text-slate-600 hover:text-red-600 dark:text-slate-300 dark:hover:text-red-400"
            >
              Explorar
            </Link>
            <Link
              href="/creators"
              className="text-slate-600 hover:text-red-600 dark:text-slate-300 dark:hover:text-red-400"
            >
              Criadores
            </Link>
            <Link
              href="/pricing"
              className="text-slate-600 hover:text-red-600 dark:text-slate-300 dark:hover:text-red-400"
            >
              Preços
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            {user ? (
              <>
                <span className="text-sm text-slate-600 dark:text-slate-300">Olá, {user.name.split(" ")[0]}</span>
                <Link href="/dashboard">
                  <Button
                    variant="ghost"
                    className="text-slate-700 hover:text-red-600 hover:bg-red-50 dark:text-slate-200 dark:hover:text-red-400"
                  >
                    Dashboard
                  </Button>
                </Link>
                <Button
                  variant="ghost"
                  onClick={handleLogout}
                  className="text-slate-700 hover:text-red-600 hover:bg-red-50 dark:text-slate-200 dark:hover:text-red-400"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sair
                </Button>
              </>
            ) : (
              <>
                <Link href="/login">
                  <Button
                    variant="ghost"
                    className="text-slate-700 hover:text-red-600 hover:bg-red-50 dark:text-slate-200 dark:hover:text-red-400"
                  >
                    Entrar
                  </Button>
                </Link>
                <Link href="/register">
                  <Button className="bg-red-600 hover:bg-red-700 text-white border-0">Começar</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <Badge className="mb-6 bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300">
            Conteúdo Exclusivo +18
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 text-balance">
            Seus segredos mais
            <span className="text-red-600 dark:text-red-400"> íntimos</span>
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-300 mb-8 max-w-2xl mx-auto text-pretty">
            Venda seu conteúdo secreto e exclusivo diretamente para seus fãs mais fiéis. Controle total, privacidade
            garantida e pagamentos seguros.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {user ? (
              <Link href="/dashboard">
                <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white border-0">
                  <Lock className="w-5 h-5 mr-2" />
                  Ir para Dashboard
                </Button>
              </Link>
            ) : (
              <Link href="/register">
                <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white border-0">
                  <Lock className="w-5 h-5 mr-2" />
                  Começar Agora
                </Button>
              </Link>
            )}
            <Link href="/explore">
              <Button
                size="lg"
                variant="outline"
                className="border-red-200 text-red-600 hover:bg-red-50 bg-transparent dark:border-red-800 dark:text-red-400 dark:hover:bg-red-950/20"
              >
                Explorar Conteúdo
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Creator Preview Slide Section */}
      <section className="py-16 px-4 bg-gradient-to-br from-red-50 to-white dark:from-red-950/20 dark:to-slate-900">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Criadores Exclusivos</h2>
            <p className="text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
              Descubra conteúdo íntimo e exclusivo dos nossos criadores mais sensuais
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="relative group overflow-hidden rounded-2xl bg-gradient-to-br from-red-100 to-red-200 dark:from-red-900/30 dark:to-red-800/30">
              <div className="aspect-[3/4] relative">
                <img
                  src="/sensual-preview-1.jpg"
                  alt="Preview exclusivo"
                  className="w-full h-full object-cover blur-sm group-hover:blur-none transition-all duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center">
                      <Heart className="w-5 h-5 text-white fill-white" />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold">Isabella</h3>
                      <p className="text-red-200 text-sm">@bella_secrets</p>
                    </div>
                  </div>
                  <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                    Assinar por 30 dias - R$ 29,90
                  </Button>
                </div>
              </div>
            </div>

            <div className="relative group overflow-hidden rounded-2xl bg-gradient-to-br from-red-100 to-red-200 dark:from-red-900/30 dark:to-red-800/30">
              <div className="aspect-[3/4] relative">
                <img
                  src="/sensual-preview-2.jpg"
                  alt="Preview exclusivo"
                  className="w-full h-full object-cover blur-sm group-hover:blur-none transition-all duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center">
                      <Heart className="w-5 h-5 text-white fill-white" />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold">Sophia</h3>
                      <p className="text-red-200 text-sm">@sophia_intimate</p>
                    </div>
                  </div>
                  <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                    Assinar por 30 dias - R$ 39,90
                  </Button>
                </div>
              </div>
            </div>

            <div className="relative group overflow-hidden rounded-2xl bg-gradient-to-br from-red-100 to-red-200 dark:from-red-900/30 dark:to-red-800/30">
              <div className="aspect-[3/4] relative">
                <img
                  src="/sensual-preview-3.jpg"
                  alt="Preview exclusivo"
                  className="w-full h-full object-cover blur-sm group-hover:blur-none transition-all duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center">
                      <Heart className="w-5 h-5 text-white fill-white" />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold">Valentina</h3>
                      <p className="text-red-200 text-sm">@val_private</p>
                    </div>
                  </div>
                  <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                    Assinar por 30 dias - R$ 49,90
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center">
            <Link href="/explore">
              <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white">
                Ver Todos os Criadores
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Plataforma segura para criadores</h2>
            <p className="text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
              Ferramentas profissionais para monetizar seu conteúdo exclusivo com total privacidade
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-slate-800/80 border-red-100">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-lg flex items-center justify-center mb-4">
                  <DollarSign className="w-6 h-6 text-white" />
                </div>
                <CardTitle>Pagamentos Discretos</CardTitle>
                <CardDescription>Receba pagamentos instantâneos com total discrição e segurança</CardDescription>
              </CardHeader>
            </Card>
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-slate-800/80 border-red-100">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-lg flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <CardTitle>Fãs Exclusivos</CardTitle>
                <CardDescription>Conecte-se com fãs que valorizam seu conteúdo único e exclusivo</CardDescription>
              </CardHeader>
            </Card>
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-slate-800/80 border-red-100">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <CardTitle>Privacidade Total</CardTitle>
                <CardDescription>
                  Controle completo sobre seu conteúdo com máxima privacidade e proteção
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-red-600 to-red-700">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Pronto para revelar seus segredos?</h2>
          <p className="text-red-100 mb-8 max-w-2xl mx-auto">
            Junte-se a milhares de criadores que já estão monetizando seu conteúdo mais íntimo
          </p>
          {user ? (
            <Link href="/upload">
              <Button size="lg" className="bg-white text-red-600 hover:bg-red-50">
                <Heart className="w-5 h-5 mr-2 fill-current" />
                Postar Conteúdo
              </Button>
            </Link>
          ) : (
            <Link href="/register">
              <Button size="lg" className="bg-white text-red-600 hover:bg-red-50">
                <Heart className="w-5 h-5 mr-2 fill-current" />
                Criar Conta Grátis
              </Button>
            </Link>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center">
                  <Heart className="w-4 h-4 text-white fill-white" />
                </div>
                <span className="text-xl font-bold text-white">Secret Fans</span>
              </div>
              <p className="text-slate-400">A plataforma mais discreta para criadores de conteúdo exclusivo</p>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-4">Produto</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/features" className="hover:text-red-400">
                    Recursos
                  </Link>
                </li>
                <li>
                  <Link href="/pricing" className="hover:text-red-400">
                    Preços
                  </Link>
                </li>
                <li>
                  <Link href="/security" className="hover:text-red-400">
                    Segurança
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-4">Suporte</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/help" className="hover:text-red-400">
                    Central de Ajuda
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-red-400">
                    Contato
                  </Link>
                </li>
                <li>
                  <Link href="/community" className="hover:text-red-400">
                    Comunidade
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-4">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/privacy" className="hover:text-red-400">
                    Privacidade
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-red-400">
                    Termos
                  </Link>
                </li>
                <li>
                  <Link href="/cookies" className="hover:text-red-400">
                    Cookies
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
            <p>&copy; 2024 Secret Fans. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
