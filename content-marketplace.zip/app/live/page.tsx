"use client"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Radio, Users, Heart, Star, Eye, Play } from "lucide-react"

const mockLiveStreams = [
  {
    id: 1,
    creator: "Sophia Sensual",
    creatorAvatar: "/abstract-profile.png",
    title: "Sessão Íntima Especial 🔥",
    viewers: 234,
    thumbnail: "/placeholder-g0tk3.png",
    category: "Adulto",
    isVip: true,
    duration: "1:23:45",
  },
  {
    id: 2,
    creator: "Isabella Fire",
    creatorAvatar: "/abstract-profile.png",
    title: "Chat Privado & Surpresas 💋",
    viewers: 156,
    thumbnail: "/makeup-tutorial.png",
    category: "Interativo",
    isVip: false,
    duration: "45:12",
  },
  {
    id: 3,
    creator: "Valentina Secret",
    creatorAvatar: "/abstract-profile.png",
    title: "Noite Especial VIP Only 🌙",
    viewers: 89,
    thumbnail: "/home-workout.png",
    category: "VIP",
    isVip: true,
    duration: "2:15:30",
  },
]

export default function LivePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-white dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/90 backdrop-blur-sm dark:bg-slate-900/90">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center">
                <Heart className="w-4 h-4 text-white fill-white" />
              </div>
              <span className="text-xl font-bold text-slate-900 dark:text-white">Secret Fans</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/explore" className="text-slate-600 hover:text-red-600 dark:text-slate-300">
                Feed
              </Link>
              <Link href="/live" className="text-red-600 font-medium flex items-center">
                <Radio className="w-4 h-4 mr-1" />
                Lives
              </Link>
              <Link href="/creators" className="text-slate-600 hover:text-red-600 dark:text-slate-300">
                Criadores
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2 flex items-center">
            <Radio className="w-8 h-8 mr-3 text-red-600" />
            Lives Ao Vivo 🔴
          </h1>
          <p className="text-slate-600 dark:text-slate-300">Transmissões exclusivas dos seus criadores favoritos</p>
        </div>

        {/* Live Streams Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockLiveStreams.map((stream) => (
            <Card key={stream.id} className="group cursor-pointer hover:shadow-lg transition-all">
              <CardContent className="p-0">
                <div className="relative aspect-video overflow-hidden rounded-t-lg">
                  <img
                    src={stream.thumbnail || "/placeholder.svg"}
                    alt={stream.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />

                  {/* Live Indicator */}
                  <div className="absolute top-3 left-3">
                    <Badge className="bg-red-600 text-white animate-pulse">
                      <Radio className="w-3 h-3 mr-1" />
                      AO VIVO
                    </Badge>
                  </div>

                  {/* VIP Badge */}
                  {stream.isVip && (
                    <div className="absolute top-3 right-3">
                      <Badge className="bg-yellow-500 text-black">
                        <Star className="w-3 h-3 mr-1" />
                        VIP
                      </Badge>
                    </div>
                  )}

                  {/* Viewers Count */}
                  <div className="absolute bottom-3 left-3">
                    <div className="bg-black/70 text-white px-2 py-1 rounded text-sm flex items-center">
                      <Users className="w-4 h-4 mr-1" />
                      {stream.viewers}
                    </div>
                  </div>

                  {/* Duration */}
                  <div className="absolute bottom-3 right-3">
                    <div className="bg-black/70 text-white px-2 py-1 rounded text-sm">{stream.duration}</div>
                  </div>

                  {/* Play Overlay */}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                    <Play className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>

                <div className="p-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <Avatar className="w-10 h-10 ring-2 ring-red-200">
                      <AvatarImage src={stream.creatorAvatar || "/placeholder.svg"} />
                      <AvatarFallback className="bg-red-100 text-red-600">{stream.creator.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900 dark:text-white line-clamp-1">{stream.title}</h3>
                      <p className="text-sm text-slate-600 dark:text-slate-400">{stream.creator}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mb-3">
                    <Badge variant="secondary" className="text-xs">
                      {stream.category}
                    </Badge>
                    <div className="flex items-center space-x-2 text-sm text-slate-500">
                      <Eye className="w-4 h-4" />
                      <span>{stream.viewers} assistindo</span>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white">
                    <Play className="w-4 h-4 mr-2" />
                    Assistir Live
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Start Live Button */}
        <div className="text-center mt-8">
          <Button
            size="lg"
            className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white"
          >
            <Radio className="w-5 h-5 mr-2" />
            Iniciar Minha Live
          </Button>
        </div>
      </div>
    </div>
  )
}
