"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import {
  Play,
  Heart,
  Eye,
  Star,
  Share2,
  Flag,
  DollarSign,
  Calendar,
  ImageIcon,
  Video,
  ArrowLeft,
  Lock,
  Users,
} from "lucide-react"

// Mock data for content detail
const mockContentDetail = {
  id: 1,
  title: "Sessão de fotos artística - Coleção Primavera",
  description: `Uma coleção exclusiva de fotos artísticas capturadas durante a primavera. 
  
  Este conjunto inclui 25 imagens em alta resolução, mostrando diferentes técnicas de iluminação natural e composição. Perfeito para quem quer aprender sobre fotografia artística ou simplesmente apreciar belas imagens.
  
  O que você vai receber:
  • 25 fotos em alta resolução (4K)
  • Guia de técnicas utilizadas
  • Configurações de câmera para cada foto
  • Acesso vitalício ao conteúdo`,
  creator: {
    name: "Maria Silva",
    avatar: "/placeholder.svg?height=60&width=60",
    followers: 2340,
    rating: 4.8,
    totalContent: 47,
  },
  price: 25.0,
  type: "image",
  thumbnail: "/artistic-photo-session-spring.jpg",
  views: 1240,
  likes: 89,
  rating: 4.8,
  totalRatings: 23,
  category: "Arte",
  tags: ["fotografia", "arte", "primavera", "natureza", "técnicas"],
  isExclusive: false,
  createdAt: "2024-01-15",
  isPurchased: false,
}

const mockReviews = [
  {
    id: 1,
    user: "João Santos",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 5,
    comment: "Conteúdo incrível! As técnicas mostradas são muito úteis e as fotos são lindas.",
    date: "2024-01-20",
  },
  {
    id: 2,
    user: "Ana Costa",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 4,
    comment: "Muito bom material, aprendi bastante sobre composição.",
    date: "2024-01-18",
  },
]

export default function ContentDetailPage({ params }: { params: { id: string } }) {
  const [isLiked, setIsLiked] = useState(false)
  const [showFullDescription, setShowFullDescription] = useState(false)

  const handlePurchase = () => {
    // Simulate purchase process
    alert("Redirecionando para pagamento...")
  }

  const handleLike = () => {
    setIsLiked(!isLiked)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/explore" className="flex items-center space-x-2 text-slate-600 hover:text-slate-900">
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar para Explorar</span>
            </Link>
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Play className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-bold text-slate-900 dark:text-white">ContentHub</span>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Media Preview */}
            <Card>
              <CardContent className="p-0">
                <div className="relative aspect-video overflow-hidden rounded-t-lg">
                  {mockContentDetail.isPurchased ? (
                    <img
                      src={mockContentDetail.thumbnail || "/placeholder.svg"}
                      alt={mockContentDetail.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="relative">
                      <img
                        src={mockContentDetail.thumbnail || "/placeholder.svg"}
                        alt={mockContentDetail.title}
                        className="w-full h-full object-cover blur-sm"
                      />
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                        <div className="text-center text-white">
                          <Lock className="w-12 h-12 mx-auto mb-4" />
                          <p className="text-lg font-semibold mb-2">Conteúdo Premium</p>
                          <p className="text-sm opacity-90">Compre para ter acesso completo</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Content Type Badge */}
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-black/70 text-white">
                      {mockContentDetail.type === "image" ? (
                        <ImageIcon className="w-3 h-3 mr-1" />
                      ) : (
                        <Video className="w-3 h-3 mr-1" />
                      )}
                      {mockContentDetail.type === "image" ? "Coleção de Fotos" : "Vídeo"}
                    </Badge>
                  </div>

                  {/* Stats Overlay */}
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="flex items-center justify-between text-white">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center">
                          <Eye className="w-4 h-4 mr-1" />
                          {mockContentDetail.views}
                        </div>
                        <div className="flex items-center">
                          <Heart className="w-4 h-4 mr-1" />
                          {mockContentDetail.likes}
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Star className="w-4 h-4 mr-1 fill-yellow-400 text-yellow-400" />
                        {mockContentDetail.rating} ({mockContentDetail.totalRatings})
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Content Info */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="secondary">{mockContentDetail.category}</Badge>
                      {mockContentDetail.isExclusive && (
                        <Badge className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                          <Star className="w-3 h-3 mr-1" />
                          Exclusivo
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-2xl mb-2">{mockContentDetail.title}</CardTitle>
                    <div className="flex items-center space-x-4 text-sm text-slate-600 dark:text-slate-400">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        {new Date(mockContentDetail.createdAt).toLocaleDateString("pt-BR")}
                      </div>
                      <div className="flex items-center">
                        <Users className="w-4 h-4 mr-1" />
                        {mockContentDetail.views} visualizações
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm" onClick={handleLike}>
                      <Heart className={`w-4 h-4 ${isLiked ? "fill-red-500 text-red-500" : ""}`} />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Share2 className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Flag className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className={`text-slate-700 dark:text-slate-300 ${!showFullDescription ? "line-clamp-3" : ""}`}>
                      {mockContentDetail.description}
                    </p>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="mt-2 p-0 h-auto"
                      onClick={() => setShowFullDescription(!showFullDescription)}
                    >
                      {showFullDescription ? "Ver menos" : "Ver mais"}
                    </Button>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2">
                    {mockContentDetail.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        #{tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Reviews */}
            <Card>
              <CardHeader>
                <CardTitle>Avaliações ({mockReviews.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockReviews.map((review) => (
                    <div key={review.id} className="space-y-2">
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={review.avatar || "/placeholder.svg"} />
                          <AvatarFallback>{review.user.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <span className="font-medium text-sm">{review.user}</span>
                            <div className="flex items-center">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`w-3 h-3 ${
                                    i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-slate-300"
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="text-xs text-slate-500">
                              {new Date(review.date).toLocaleDateString("pt-BR")}
                            </span>
                          </div>
                          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{review.comment}</p>
                        </div>
                      </div>
                      {review.id !== mockReviews[mockReviews.length - 1].id && <Separator />}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Purchase Card */}
            <Card>
              <CardHeader>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 mb-2">R$ {mockContentDetail.price.toFixed(2)}</div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Acesso vitalício</p>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  size="lg"
                  onClick={handlePurchase}
                >
                  <DollarSign className="w-4 h-4 mr-2" />
                  Comprar Agora
                </Button>
                <div className="text-center">
                  <p className="text-xs text-slate-500">Pagamento seguro • Acesso imediato</p>
                </div>
              </CardContent>
            </Card>

            {/* Creator Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Sobre o Criador</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-3 mb-4">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={mockContentDetail.creator.avatar || "/placeholder.svg"} />
                    <AvatarFallback>{mockContentDetail.creator.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold">{mockContentDetail.creator.name}</h3>
                    <div className="flex items-center text-sm text-slate-600 dark:text-slate-400">
                      <Star className="w-3 h-3 mr-1 fill-yellow-400 text-yellow-400" />
                      {mockContentDetail.creator.rating} • {mockContentDetail.creator.followers} seguidores
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-center text-sm">
                  <div>
                    <div className="font-semibold">{mockContentDetail.creator.totalContent}</div>
                    <div className="text-slate-500">Conteúdos</div>
                  </div>
                  <div>
                    <div className="font-semibold">{mockContentDetail.creator.followers}</div>
                    <div className="text-slate-500">Seguidores</div>
                  </div>
                </div>
                <Button variant="outline" className="w-full mt-4 bg-transparent">
                  Ver Perfil
                </Button>
              </CardContent>
            </Card>

            {/* Related Content */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Conteúdo Relacionado</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center space-x-3">
                      <div className="w-16 h-12 bg-slate-200 dark:bg-slate-700 rounded overflow-hidden">
                        <img
                          src={`/related-content-collage.png?height=48&width=64&query=related content ${i}`}
                          alt="Related content"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">Conteúdo relacionado {i}</p>
                        <p className="text-xs text-slate-500">R$ 20,00</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
