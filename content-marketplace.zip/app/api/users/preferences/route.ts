import { type NextRequest, NextResponse } from "next/server"

// Update user preferences
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { emailNotifications, pushNotifications, marketingEmails, profileVisibility, showEarnings } = body

    // Mock update - in real app, update database
    const updatedPreferences = {
      emailNotifications: emailNotifications ?? true,
      pushNotifications: pushNotifications ?? false,
      marketingEmails: marketingEmails ?? true,
      profileVisibility: profileVisibility ?? "public",
      showEarnings: showEarnings ?? false,
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      preferences: updatedPreferences,
      message: "Preferences updated successfully",
    })
  } catch (error) {
    console.error("Error updating preferences:", error)
    return NextResponse.json({ error: "Failed to update preferences" }, { status: 500 })
  }
}

// Get user preferences
export async function GET() {
  try {
    // Mock preferences - in real app, get from database
    const preferences = {
      emailNotifications: true,
      pushNotifications: false,
      marketingEmails: true,
      profileVisibility: "public",
      showEarnings: false,
    }

    return NextResponse.json(preferences)
  } catch (error) {
    console.error("Error fetching preferences:", error)
    return NextResponse.json({ error: "Failed to fetch preferences" }, { status: 500 })
  }
}
