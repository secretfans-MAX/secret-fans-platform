import { type NextRequest, NextResponse } from "next/server"

// Get user profile
export async function GET(request: NextRequest) {
  try {
    // Mock user data - in real app, get from database
    const mockUser = {
      id: 1,
      name: "Maria Silva",
      email: "maria@email.com",
      phone: "+55 11 99999-9999",
      bio: "Fotógrafa profissional especializada em retratos artísticos.",
      location: "São Paulo, SP",
      avatar: "/placeholder.svg",
      isCreator: true,
      isVerified: true,
      joinDate: "2023-06-15",
      stats: {
        followers: 2340,
        following: 156,
        totalContent: 47,
        totalEarnings: 2847.5,
      },
      preferences: {
        emailNotifications: true,
        pushNotifications: false,
        marketingEmails: true,
        profileVisibility: "public",
        showEarnings: false,
      },
    }

    return NextResponse.json(mockUser)
  } catch (error) {
    console.error("Error fetching user profile:", error)
    return NextResponse.json({ error: "Failed to fetch profile" }, { status: 500 })
  }
}

// Update user profile
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, phone, bio, location, preferences } = body

    // Mock validation
    if (!name || !email) {
      return NextResponse.json({ error: "Name and email are required" }, { status: 400 })
    }

    // Mock update - in real app, update database
    const updatedUser = {
      id: 1,
      name,
      email,
      phone,
      bio,
      location,
      preferences,
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      user: updatedUser,
      message: "Profile updated successfully",
    })
  } catch (error) {
    console.error("Error updating profile:", error)
    return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
  }
}
