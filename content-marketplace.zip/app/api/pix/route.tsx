import { type NextRequest, NextResponse } from "next/server"

// Generate PIX payment code
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { contentId, amount, userEmail } = body

    if (!contentId || !amount || !userEmail) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Mock PIX code generation
    const pixCode = `00020126580014BR.GOV.BCB.PIX0136${Math.random().toString(36).substr(2, 32)}520400005303986540${amount.toFixed(2)}5802BR5925CONTENTHUB PAGAMENTOS6009SAO PAULO62070503***6304`

    const qrCodeUrl = `data:image/svg+xml;base64,${btoa(`
      <svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
        <rect width="200" height="200" fill="white"/>
        <text x="100" y="100" text-anchor="middle" font-family="Arial" font-size="12">QR Code PIX</text>
        <text x="100" y="120" text-anchor="middle" font-family="Arial" font-size="8">R$ ${amount.toFixed(2)}</text>
      </svg>
    `)}`

    return NextResponse.json({
      success: true,
      pixCode,
      qrCodeUrl,
      amount,
      expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString(), // 30 minutes
      paymentId: `pix_${Math.random().toString(36).substr(2, 9)}`,
    })
  } catch (error) {
    console.error("PIX generation error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
