"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/contexts/auth-context"
import {
  Upload,
  DollarSign,
  Eye,
  TrendingUp,
  Users,
  Calendar,
  MoreHorizontal,
  BarChart3,
  Settings,
  Bell,
  Heart,
  LogOut,
  Play,
  MessageCircle,
} from "lucide-react"

// Mock data
const mockStats = {
  totalEarnings: 2847.5,
  monthlyEarnings: 892.3,
  totalViews: 15420,
  totalLikes: 3240,
  followers: 1250,
  contentCount: 47,
}

const mockContent = [
  {
    id: 1,
    title: "Sessão de fotos exclusiva",
    type: "image",
    price: 25.0,
    views: 342,
    likes: 89,
    sales: 12,
    earnings: 300.0,
    status: "published",
    createdAt: "2024-01-15",
  },
  {
    id: 2,
    title: "Vídeo tutorial de maquiagem",
    type: "video",
    price: 45.0,
    views: 156,
    likes: 34,
    sales: 8,
    earnings: 360.0,
    status: "published",
    createdAt: "2024-01-12",
  },
  {
    id: 3,
    title: "Behind the scenes",
    type: "video",
    price: 15.0,
    views: 89,
    likes: 23,
    sales: 5,
    earnings: 75.0,
    status: "draft",
    createdAt: "2024-01-10",
  },
]

// Mock data for subscribers
const mockSubscriberData = {
  subscriptions: [
    {
      id: 1,
      creatorName: "Bella Santos",
      creatorAvatar: "/sensual-preview-1.jpg",
      subscriptionDate: "2024-01-10",
      nextBilling: "2024-02-10",
      price: 29.99,
      status: "active",
      contentCount: 45,
    },
    {
      id: 2,
      creatorName: "Luna Rose",
      creatorAvatar: "/sensual-preview-2.jpg",
      subscriptionDate: "2024-01-05",
      nextBilling: "2024-02-05",
      price: 39.99,
      status: "active",
      contentCount: 32,
    },
  ],
  purchasedContent: [
    {
      id: 1,
      title: "Sessão de fotos exclusiva",
      creator: "Bella Santos",
      price: 25.0,
      purchaseDate: "2024-01-15",
      type: "image",
      thumbnail: "/sensual-preview-1.jpg",
    },
    {
      id: 2,
      title: "Vídeo especial",
      creator: "Luna Rose",
      price: 45.0,
      purchaseDate: "2024-01-12",
      type: "video",
      thumbnail: "/sensual-preview-2.jpg",
    },
  ],
  chats: [
    {
      id: 1,
      creatorName: "Bella Santos",
      creatorAvatar: "/sensual-preview-1.jpg",
      lastMessage: "Obrigada pelo apoio! 💕",
      lastMessageTime: "há 2 horas",
      unreadCount: 2,
    },
    {
      id: 2,
      creatorName: "Luna Rose",
      creatorAvatar: "/sensual-preview-2.jpg",
      lastMessage: "Você viu meu novo conteúdo?",
      lastMessageTime: "há 1 dia",
      unreadCount: 0,
    },
  ],
}

export default function Dashboard() {
  const [selectedTab, setSelectedTab] = useState("overview")
  const { user, logout, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-white to-red-50 dark:from-slate-900 dark:to-red-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center mx-auto mb-4">
            <Heart className="w-4 h-4 text-white fill-white animate-pulse" />
          </div>
          <p className="text-slate-600 dark:text-slate-400">Carregando...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  if (user.type === "buyer") {
    return <SubscriberDashboard user={user} handleLogout={handleLogout} />
  }

  return <CreatorDashboard user={user} handleLogout={handleLogout} />
}

function SubscriberDashboard({ user, handleLogout }: { user: any; handleLogout: () => void }) {
  const [selectedTab, setSelectedTab] = useState("subscriptions")

  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-red-50 dark:from-slate-900 dark:to-red-950">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80 border-red-100 dark:border-red-900">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center">
                  <Heart className="w-4 h-4 text-white fill-white" />
                </div>
                <span className="text-xl font-bold text-slate-900 dark:text-white">Secret Fans</span>
              </Link>
              <Badge variant="secondary" className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                Assinante
              </Badge>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm">
                <Bell className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={handleLogout} className="text-red-600 hover:text-red-700">
                <LogOut className="w-4 h-4" />
              </Button>
              <Avatar className="w-8 h-8">
                <AvatarImage src={user.avatar || "/placeholder.svg"} />
                <AvatarFallback className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Bem-vindo, {user.name}! 💕</h1>
          <p className="text-slate-600 dark:text-slate-300">
            Acesse seu conteúdo exclusivo e converse com seus criadores favoritos
          </p>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-4">
            <Link href="/explore">
              <Button className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800">
                <Heart className="w-4 h-4 mr-2" />
                Explorar Criadores
              </Button>
            </Link>
            <Link href="/chat">
              <Button
                variant="outline"
                className="border-red-200 text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-300 dark:hover:bg-red-950 bg-transparent"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Mensagens
              </Button>
            </Link>
          </div>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 lg:w-[400px] bg-red-50 dark:bg-red-950">
            <TabsTrigger
              value="subscriptions"
              className="data-[state=active]:bg-red-600 data-[state=active]:text-white"
            >
              Assinaturas
            </TabsTrigger>
            <TabsTrigger value="content" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Meu Conteúdo
            </TabsTrigger>
            <TabsTrigger value="chats" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Conversas
            </TabsTrigger>
          </TabsList>

          {/* Subscriptions Tab */}
          <TabsContent value="subscriptions" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Minhas Assinaturas</h2>
              <Link href="/explore">
                <Button className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800">
                  <Heart className="w-4 h-4 mr-2" />
                  Encontrar Criadores
                </Button>
              </Link>
            </div>

            <div className="grid gap-6">
              {mockSubscriberData.subscriptions.map((subscription) => (
                <Card key={subscription.id} className="border-red-100 dark:border-red-900">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <Avatar className="w-16 h-16">
                          <AvatarImage src={subscription.creatorAvatar || "/placeholder.svg"} />
                          <AvatarFallback>{subscription.creatorName[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold text-slate-900 dark:text-white">{subscription.creatorName}</h3>
                          <div className="flex items-center space-x-4 mt-1">
                            <Badge
                              variant="default"
                              className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                            >
                              Ativa
                            </Badge>
                            <span className="text-sm text-slate-500">{subscription.contentCount} conteúdos</span>
                          </div>
                          <p className="text-sm text-slate-500 mt-1">
                            Próxima cobrança: {new Date(subscription.nextBilling).toLocaleDateString("pt-BR")}
                          </p>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-lg font-bold text-red-700 dark:text-red-400">
                          R$ {subscription.price.toFixed(2)}/mês
                        </div>
                        <div className="flex space-x-2 mt-2">
                          <Button size="sm" variant="outline">
                            Ver Perfil
                          </Button>
                          <Button size="sm" variant="outline" className="text-red-600 bg-transparent">
                            Cancelar
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Content Tab */}
          <TabsContent value="content" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Conteúdo Comprado</h2>
            </div>

            <div className="grid gap-6">
              {mockSubscriberData.purchasedContent.map((content) => (
                <Card key={content.id} className="border-red-100 dark:border-red-900">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-16 h-16 bg-gradient-to-br from-slate-200 to-slate-300 dark:from-slate-700 dark:to-slate-600 rounded-lg flex items-center justify-center overflow-hidden">
                          <img
                            src={content.thumbnail || "/placeholder.svg"}
                            alt={content.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h3 className="font-semibold text-slate-900 dark:text-white">{content.title}</h3>
                          <p className="text-sm text-slate-500">Por {content.creator}</p>
                          <p className="text-sm text-slate-500">
                            Comprado em {new Date(content.purchaseDate).toLocaleDateString("pt-BR")}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <div className="text-sm font-medium text-green-600">R$ {content.price.toFixed(2)}</div>
                          <Badge
                            variant="secondary"
                            className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
                          >
                            {content.type === "image" ? "Foto" : "Vídeo"}
                          </Badge>
                        </div>
                        <Button size="sm" className="bg-red-600 hover:bg-red-700">
                          <Eye className="w-4 h-4 mr-2" />
                          Ver Conteúdo
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Chats Tab */}
          <TabsContent value="chats" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Minhas Conversas</h2>
              <Link href="/chat">
                <Button className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Abrir Chat
                </Button>
              </Link>
            </div>

            <div className="grid gap-4">
              {mockSubscriberData.chats.map((chat) => (
                <Card
                  key={chat.id}
                  className="border-red-100 dark:border-red-900 hover:bg-red-50 dark:hover:bg-red-950 cursor-pointer"
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={chat.creatorAvatar || "/placeholder.svg"} />
                          <AvatarFallback>{chat.creatorName[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold text-slate-900 dark:text-white">{chat.creatorName}</h3>
                          <p className="text-sm text-slate-500">{chat.lastMessage}</p>
                        </div>
                      </div>

                      <div className="text-right">
                        <p className="text-xs text-slate-500">{chat.lastMessageTime}</p>
                        {chat.unreadCount > 0 && (
                          <Badge variant="default" className="bg-red-600 text-white mt-1">
                            {chat.unreadCount}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

function CreatorDashboard({ user, handleLogout }: { user: any; handleLogout: () => void }) {
  const [selectedTab, setSelectedTab] = useState("overview")

  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-red-50 dark:from-slate-900 dark:to-red-950">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80 border-red-100 dark:border-red-900">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center">
                  <Heart className="w-4 h-4 text-white fill-white" />
                </div>
                <span className="text-xl font-bold text-slate-900 dark:text-white">Secret Fans</span>
              </Link>
              <Badge variant="secondary" className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                Criador
              </Badge>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm">
                <Bell className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={handleLogout} className="text-red-600 hover:text-red-700">
                <LogOut className="w-4 h-4" />
              </Button>
              <Avatar className="w-8 h-8">
                <AvatarImage src={user.avatar || "/placeholder.svg"} />
                <AvatarFallback className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Olá, {user.name}! 👋</h1>
          <p className="text-slate-600 dark:text-slate-300">Gerencie seu conteúdo secreto e acompanhe suas vendas</p>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-4">
            <Link href="/upload">
              <Button className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800">
                <Upload className="w-4 h-4 mr-2" />
                Novo Conteúdo Secreto
              </Button>
            </Link>
            <Button
              variant="outline"
              className="border-red-200 text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-300 dark:hover:bg-red-950 bg-transparent"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Relatórios
            </Button>
            <Button
              variant="outline"
              className="border-red-200 text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-300 dark:hover:bg-red-950 bg-transparent"
            >
              <Users className="w-4 h-4 mr-2" />
              Fãs Secretos
            </Button>
          </div>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-[400px] bg-red-50 dark:bg-red-950">
            <TabsTrigger value="overview" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Visão Geral
            </TabsTrigger>
            <TabsTrigger value="content" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Conteúdo
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Analytics
            </TabsTrigger>
            <TabsTrigger value="earnings" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Ganhos
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-red-100 dark:border-red-900">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Ganhos Totais</CardTitle>
                  <DollarSign className="h-4 w-4 text-red-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-700 dark:text-red-400">
                    R$ {mockStats.totalEarnings.toFixed(2)}
                  </div>
                  <p className="text-xs text-muted-foreground">+12% em relação ao mês passado</p>
                </CardContent>
              </Card>

              <Card className="border-red-100 dark:border-red-900">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Visualizações</CardTitle>
                  <Eye className="h-4 w-4 text-red-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-700 dark:text-red-400">
                    {mockStats.totalViews.toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">+8% em relação ao mês passado</p>
                </CardContent>
              </Card>

              <Card className="border-red-100 dark:border-red-900">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Fãs Secretos</CardTitle>
                  <Users className="h-4 w-4 text-red-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-700 dark:text-red-400">
                    {mockStats.followers.toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">+23 novos esta semana</p>
                </CardContent>
              </Card>

              <Card className="border-red-100 dark:border-red-900">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Conteúdos</CardTitle>
                  <Upload className="h-4 w-4 text-red-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-700 dark:text-red-400">{mockStats.contentCount}</div>
                  <p className="text-xs text-muted-foreground">3 publicados esta semana</p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card className="border-red-100 dark:border-red-900">
              <CardHeader>
                <CardTitle>Atividade Recente</CardTitle>
                <CardDescription>Suas últimas interações e vendas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Nova venda: "Sessão de fotos exclusiva"</p>
                      <p className="text-xs text-muted-foreground">há 2 horas</p>
                    </div>
                    <Badge
                      variant="secondary"
                      className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                    >
                      +R$ 25,00
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Novo fã secreto: @usuario123</p>
                      <p className="text-xs text-muted-foreground">há 4 horas</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Conteúdo curtido 15 vezes</p>
                      <p className="text-xs text-muted-foreground">há 6 horas</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Content Tab */}
          <TabsContent value="content" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Meu Conteúdo</h2>
              <Link href="/upload">
                <Button className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800">
                  <Upload className="w-4 h-4 mr-2" />
                  Adicionar Conteúdo
                </Button>
              </Link>
            </div>

            <div className="grid gap-6">
              {mockContent.map((content) => (
                <Card key={content.id} className="border-red-100 dark:border-red-900">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-16 h-16 bg-gradient-to-br from-slate-200 to-slate-300 dark:from-slate-700 dark:to-slate-600 rounded-lg flex items-center justify-center">
                          {content.type === "image" ? (
                            <Eye className="w-6 h-6 text-slate-500" />
                          ) : (
                            <Play className="w-6 h-6 text-slate-500" />
                          )}
                        </div>
                        <div>
                          <h3 className="font-semibold text-slate-900 dark:text-white">{content.title}</h3>
                          <div className="flex items-center space-x-4 mt-1">
                            <Badge variant={content.status === "published" ? "default" : "secondary"}>
                              {content.status === "published" ? "Publicado" : "Rascunho"}
                            </Badge>
                            <span className="text-sm text-slate-500">R$ {content.price.toFixed(2)}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-6">
                        <div className="text-center">
                          <div className="text-sm font-medium">{content.views}</div>
                          <div className="text-xs text-slate-500">Visualizações</div>
                        </div>
                        <div className="text-center">
                          <div className="text-sm font-medium">{content.likes}</div>
                          <div className="text-xs text-slate-500">Curtidas</div>
                        </div>
                        <div className="text-center">
                          <div className="text-sm font-medium">{content.sales}</div>
                          <div className="text-xs text-slate-500">Vendas</div>
                        </div>
                        <div className="text-center">
                          <div className="text-sm font-medium text-green-600">R$ {content.earnings.toFixed(2)}</div>
                          <div className="text-xs text-slate-500">Ganhos</div>
                        </div>

                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <Card className="border-red-100 dark:border-red-900">
              <CardHeader>
                <CardTitle>Analytics em Desenvolvimento</CardTitle>
                <CardDescription>
                  Gráficos detalhados de performance, demografia de audiência e tendências de vendas estarão disponíveis
                  em breve.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-700 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <BarChart3 className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-500">Gráficos de analytics em breve</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Earnings Tab */}
          <TabsContent value="earnings" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="border-red-100 dark:border-red-900">
                <CardHeader>
                  <CardTitle>Ganhos Este Mês</CardTitle>
                  <CardDescription>Janeiro 2024</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    R$ {mockStats.monthlyEarnings.toFixed(2)}
                  </div>
                  <div className="flex items-center text-sm text-slate-500">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    +15% em relação ao mês anterior
                  </div>
                </CardContent>
              </Card>

              <Card className="border-red-100 dark:border-red-900">
                <CardHeader>
                  <CardTitle>Próximo Pagamento</CardTitle>
                  <CardDescription>Estimativa baseada nas vendas atuais</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-2">R$ 756,40</div>
                  <div className="flex items-center text-sm text-slate-500">
                    <Calendar className="w-4 h-4 mr-1" />
                    Pagamento em 5 dias
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-red-100 dark:border-red-900">
              <CardHeader>
                <CardTitle>Histórico de Pagamentos</CardTitle>
                <CardDescription>Seus últimos pagamentos recebidos</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Pagamento de Dezembro</p>
                      <p className="text-sm text-slate-500">31 de Dezembro, 2023</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-green-600">R$ 1.245,80</p>
                      <Badge
                        variant="secondary"
                        className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                      >
                        Pago
                      </Badge>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Pagamento de Novembro</p>
                      <p className="text-sm text-slate-500">30 de Novembro, 2023</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-green-600">R$ 987,50</p>
                      <Badge
                        variant="secondary"
                        className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                      >
                        Pago
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
