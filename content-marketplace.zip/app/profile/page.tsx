"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import {
  Camera,
  Settings,
  Shield,
  CreditCard,
  Eye,
  EyeOff,
  Save,
  Play,
  ArrowLeft,
  MapPin,
  Calendar,
  Star,
} from "lucide-react"

// Mock user data
const mockUser = {
  id: 1,
  name: "Maria Silva",
  email: "maria@email.com",
  phone: "+55 11 99999-9999",
  bio: "Fotógrafa profissional especializada em retratos artísticos e fotografia de natureza. Apaixonada por capturar momentos únicos e ensinar técnicas de fotografia.",
  location: "São Paulo, SP",
  joinDate: "2023-06-15",
  avatar: "/placeholder.svg?height=120&width=120",
  coverImage: "/placeholder.svg?height=200&width=800",
  isCreator: true,
  isVerified: true,
  stats: {
    followers: 2340,
    following: 156,
    totalContent: 47,
    totalEarnings: 2847.5,
    totalViews: 15420,
    totalLikes: 3240,
  },
  preferences: {
    emailNotifications: true,
    pushNotifications: false,
    marketingEmails: true,
    profileVisibility: "public",
    showEarnings: false,
  },
}

export default function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [formData, setFormData] = useState({
    name: mockUser.name,
    email: mockUser.email,
    phone: mockUser.phone,
    bio: mockUser.bio,
    location: mockUser.location,
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })
  const [preferences, setPreferences] = useState(mockUser.preferences)

  const handleSave = () => {
    // Simulate save
    setIsEditing(false)
    alert("Perfil atualizado com sucesso!")
  }

  const handlePreferenceChange = (key: string, value: boolean | string) => {
    setPreferences((prev) => ({ ...prev, [key]: value }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/dashboard" className="flex items-center space-x-2 text-slate-600 hover:text-slate-900">
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar ao Dashboard</span>
            </Link>
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Play className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-bold text-slate-900 dark:text-white">ContentHub</span>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Profile Header */}
          <Card className="mb-8">
            <CardContent className="p-0">
              {/* Cover Image */}
              <div className="relative h-48 bg-gradient-to-r from-purple-600 to-blue-600 rounded-t-lg overflow-hidden">
                <img
                  src={mockUser.coverImage || "/placeholder.svg"}
                  alt="Cover"
                  className="w-full h-full object-cover opacity-50"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600/50 to-blue-600/50" />
                {isEditing && (
                  <Button variant="secondary" size="sm" className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm">
                    <Camera className="w-4 h-4 mr-2" />
                    Alterar Capa
                  </Button>
                )}
              </div>

              {/* Profile Info */}
              <div className="relative px-6 pb-6">
                <div className="flex flex-col md:flex-row md:items-end md:space-x-6 -mt-16">
                  {/* Avatar */}
                  <div className="relative">
                    <Avatar className="w-32 h-32 border-4 border-white dark:border-slate-800">
                      <AvatarImage src={mockUser.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="text-2xl">{mockUser.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    {isEditing && (
                      <Button
                        size="sm"
                        className="absolute bottom-0 right-0 rounded-full w-8 h-8 p-0"
                        variant="secondary"
                      >
                        <Camera className="w-4 h-4" />
                      </Button>
                    )}
                  </div>

                  {/* User Info */}
                  <div className="flex-1 mt-4 md:mt-0">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                      <div>
                        <div className="flex items-center space-x-2 mb-2">
                          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{mockUser.name}</h1>
                          {mockUser.isVerified && (
                            <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300">
                              <Shield className="w-3 h-3 mr-1" />
                              Verificado
                            </Badge>
                          )}
                          {mockUser.isCreator && (
                            <Badge className="bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300">
                              <Star className="w-3 h-3 mr-1" />
                              Criador
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-slate-600 dark:text-slate-400">
                          <div className="flex items-center">
                            <MapPin className="w-4 h-4 mr-1" />
                            {mockUser.location}
                          </div>
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            Desde {new Date(mockUser.joinDate).toLocaleDateString("pt-BR")}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3 mt-4 md:mt-0">
                        <Button
                          variant={isEditing ? "default" : "outline"}
                          onClick={() => (isEditing ? handleSave() : setIsEditing(true))}
                        >
                          {isEditing ? (
                            <>
                              <Save className="w-4 h-4 mr-2" />
                              Salvar
                            </>
                          ) : (
                            <>
                              <Settings className="w-4 h-4 mr-2" />
                              Editar Perfil
                            </>
                          )}
                        </Button>
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                      <div className="text-center">
                        <div className="text-xl font-bold text-slate-900 dark:text-white">
                          {mockUser.stats.followers}
                        </div>
                        <div className="text-sm text-slate-500">Seguidores</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-slate-900 dark:text-white">
                          {mockUser.stats.following}
                        </div>
                        <div className="text-sm text-slate-500">Seguindo</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-slate-900 dark:text-white">
                          {mockUser.stats.totalContent}
                        </div>
                        <div className="text-sm text-slate-500">Conteúdos</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-green-600">
                          R$ {mockUser.stats.totalEarnings.toFixed(0)}
                        </div>
                        <div className="text-sm text-slate-500">Ganhos</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Profile Tabs */}
          <Tabs defaultValue="info" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="info">Informações</TabsTrigger>
              <TabsTrigger value="security">Segurança</TabsTrigger>
              <TabsTrigger value="notifications">Notificações</TabsTrigger>
              <TabsTrigger value="billing">Pagamentos</TabsTrigger>
            </TabsList>

            {/* Personal Information */}
            <TabsContent value="info" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Informações Pessoais</CardTitle>
                  <CardDescription>Gerencie suas informações básicas de perfil</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Nome Completo</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">Telefone</Label>
                      <Input
                        id="phone"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                    <div>
                      <Label htmlFor="location">Localização</Label>
                      <Input
                        id="location"
                        value={formData.location}
                        onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="bio">Biografia</Label>
                    <Textarea
                      id="bio"
                      rows={4}
                      value={formData.bio}
                      onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                      disabled={!isEditing}
                      placeholder="Conte um pouco sobre você..."
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Security */}
            <TabsContent value="security" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Alterar Senha</CardTitle>
                  <CardDescription>Mantenha sua conta segura com uma senha forte</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="currentPassword">Senha Atual</Label>
                    <div className="relative">
                      <Input
                        id="currentPassword"
                        type={showPassword ? "text" : "password"}
                        value={formData.currentPassword}
                        onChange={(e) => setFormData({ ...formData, currentPassword: e.target.value })}
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="newPassword">Nova Senha</Label>
                      <Input
                        id="newPassword"
                        type="password"
                        value={formData.newPassword}
                        onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="confirmPassword">Confirmar Nova Senha</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        value={formData.confirmPassword}
                        onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      />
                    </div>
                  </div>

                  <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                    Atualizar Senha
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Privacidade</CardTitle>
                  <CardDescription>Controle quem pode ver seu perfil e conteúdo</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Perfil Público</Label>
                      <p className="text-sm text-slate-500">Permite que outros usuários vejam seu perfil</p>
                    </div>
                    <Switch
                      checked={preferences.profileVisibility === "public"}
                      onCheckedChange={(checked) =>
                        handlePreferenceChange("profileVisibility", checked ? "public" : "private")
                      }
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Mostrar Ganhos</Label>
                      <p className="text-sm text-slate-500">Exibe seus ganhos totais no perfil público</p>
                    </div>
                    <Switch
                      checked={preferences.showEarnings}
                      onCheckedChange={(checked) => handlePreferenceChange("showEarnings", checked)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications */}
            <TabsContent value="notifications" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Preferências de Notificação</CardTitle>
                  <CardDescription>Escolha como e quando você quer ser notificado</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Notificações por Email</Label>
                      <p className="text-sm text-slate-500">Receba atualizações importantes por email</p>
                    </div>
                    <Switch
                      checked={preferences.emailNotifications}
                      onCheckedChange={(checked) => handlePreferenceChange("emailNotifications", checked)}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Notificações Push</Label>
                      <p className="text-sm text-slate-500">Receba notificações em tempo real no navegador</p>
                    </div>
                    <Switch
                      checked={preferences.pushNotifications}
                      onCheckedChange={(checked) => handlePreferenceChange("pushNotifications", checked)}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Emails de Marketing</Label>
                      <p className="text-sm text-slate-500">Receba dicas, novidades e promoções</p>
                    </div>
                    <Switch
                      checked={preferences.marketingEmails}
                      onCheckedChange={(checked) => handlePreferenceChange("marketingEmails", checked)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Billing */}
            <TabsContent value="billing" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Informações de Pagamento</CardTitle>
                  <CardDescription>Gerencie seus métodos de pagamento e dados bancários</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label>Banco</Label>
                      <Input placeholder="Nome do banco" />
                    </div>
                    <div>
                      <Label>Agência</Label>
                      <Input placeholder="0000" />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label>Conta</Label>
                      <Input placeholder="00000-0" />
                    </div>
                    <div>
                      <Label>Tipo de Conta</Label>
                      <Input placeholder="Corrente" />
                    </div>
                  </div>

                  <div>
                    <Label>Chave PIX</Label>
                    <Input placeholder="Seu email, telefone ou chave aleatória" />
                  </div>

                  <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                    <CreditCard className="w-4 h-4 mr-2" />
                    Salvar Informações
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Histórico de Ganhos</CardTitle>
                  <CardDescription>Acompanhe seus ganhos e saques</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">Saque Janeiro 2024</p>
                        <p className="text-sm text-slate-500">31 de Janeiro, 2024</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-green-600">R$ 892,30</p>
                        <Badge variant="secondary">Processado</Badge>
                      </div>
                    </div>
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">Saque Dezembro 2023</p>
                        <p className="text-sm text-slate-500">31 de Dezembro, 2023</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-green-600">R$ 1.245,80</p>
                        <Badge variant="secondary">Processado</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
