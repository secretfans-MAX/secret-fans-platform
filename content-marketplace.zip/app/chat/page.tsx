"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { MessageCircle, Send, Heart, Search, Phone, Video, MoreVertical, Paperclip, Smile } from "lucide-react"

const mockChats = [
  {
    id: 1,
    creator: "Sophia Sensual",
    avatar: "/abstract-profile.png",
    lastMessage: "Obrigada pelo apoio! 💋",
    timestamp: "2min",
    unread: 3,
    isOnline: true,
    isVip: true,
  },
  {
    id: 2,
    creator: "Isabella Fire",
    avatar: "/abstract-profile.png",
    lastMessage: "Você viu minha nova live?",
    timestamp: "15min",
    unread: 0,
    isOnline: true,
    isVip: false,
  },
  {
    id: 3,
    creator: "Valentina Secret",
    avatar: "/abstract-profile.png",
    lastMessage: "Tenho uma surpresa para você...",
    timestamp: "1h",
    unread: 1,
    isOnline: false,
    isVip: true,
  },
]

const mockMessages = [
  {
    id: 1,
    sender: "creator",
    message: "Oi amor! Como você está? 💋",
    timestamp: "14:30",
    type: "text",
  },
  {
    id: 2,
    sender: "user",
    message: "Oi! Estou bem, adorei sua última live!",
    timestamp: "14:32",
    type: "text",
  },
  {
    id: 3,
    sender: "creator",
    message: "Que bom que gostou! Tenho mais conteúdo especial chegando... 🔥",
    timestamp: "14:35",
    type: "text",
  },
  {
    id: 4,
    sender: "creator",
    message: "Quer ver uma prévia exclusiva?",
    timestamp: "14:36",
    type: "text",
  },
]

export default function ChatPage() {
  const [selectedChat, setSelectedChat] = useState(mockChats[0])
  const [newMessage, setNewMessage] = useState("")

  const sendMessage = () => {
    if (newMessage.trim()) {
      console.log("[v0] Sending message:", newMessage)
      setNewMessage("")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-white dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/90 backdrop-blur-sm dark:bg-slate-900/90">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center">
                <Heart className="w-4 h-4 text-white fill-white" />
              </div>
              <span className="text-xl font-bold text-slate-900 dark:text-white">Secret Fans</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/explore" className="text-slate-600 hover:text-red-600 dark:text-slate-300">
                Feed
              </Link>
              <Link href="/live" className="text-slate-600 hover:text-red-600 dark:text-slate-300">
                Lives
              </Link>
              <Link href="/chat" className="text-red-600 font-medium flex items-center">
                <MessageCircle className="w-4 h-4 mr-1" />
                Chat
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 h-[calc(100vh-80px)]">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full">
          {/* Chat List */}
          <Card className="md:col-span-1">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold flex items-center">
                  <MessageCircle className="w-5 h-5 mr-2 text-red-600" />
                  Conversas
                </h2>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input placeholder="Buscar conversas..." className="pl-10" />
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-1">
                {mockChats.map((chat) => (
                  <div
                    key={chat.id}
                    onClick={() => setSelectedChat(chat)}
                    className={`p-3 cursor-pointer hover:bg-red-50 dark:hover:bg-slate-700 transition-colors ${
                      selectedChat.id === chat.id ? "bg-red-50 dark:bg-slate-700" : ""
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={chat.avatar || "/placeholder.svg"} />
                          <AvatarFallback className="bg-red-100 text-red-600">{chat.creator.charAt(0)}</AvatarFallback>
                        </Avatar>
                        {chat.isOnline && (
                          <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-1">
                            <p className="font-semibold text-sm truncate">{chat.creator}</p>
                            {chat.isVip && <Badge className="bg-yellow-500 text-black text-xs px-1">VIP</Badge>}
                          </div>
                          <span className="text-xs text-slate-500">{chat.timestamp}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <p className="text-sm text-slate-600 dark:text-slate-400 truncate">{chat.lastMessage}</p>
                          {chat.unread > 0 && (
                            <Badge className="bg-red-600 text-white text-xs min-w-[20px] h-5 flex items-center justify-center rounded-full">
                              {chat.unread}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Chat Window */}
          <Card className="md:col-span-2 flex flex-col">
            {/* Chat Header */}
            <CardHeader className="pb-3 border-b">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={selectedChat.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="bg-red-100 text-red-600">
                        {selectedChat.creator.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    {selectedChat.isOnline && (
                      <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                    )}
                  </div>
                  <div>
                    <div className="flex items-center space-x-1">
                      <h3 className="font-semibold">{selectedChat.creator}</h3>
                      {selectedChat.isVip && <Badge className="bg-yellow-500 text-black text-xs">VIP</Badge>}
                    </div>
                    <p className="text-sm text-slate-500">
                      {selectedChat.isOnline ? "Online agora" : "Visto por último há 2h"}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm">
                    <Phone className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Video className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            {/* Messages */}
            <CardContent className="flex-1 p-4 overflow-y-auto">
              <div className="space-y-4">
                {mockMessages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        message.sender === "user"
                          ? "bg-red-600 text-white"
                          : "bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white"
                      }`}
                    >
                      <p className="text-sm">{message.message}</p>
                      <p className={`text-xs mt-1 ${message.sender === "user" ? "text-red-100" : "text-slate-500"}`}>
                        {message.timestamp}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>

            {/* Message Input */}
            <div className="p-4 border-t">
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm">
                  <Paperclip className="w-4 h-4" />
                </Button>
                <Input
                  placeholder="Digite sua mensagem..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                  className="flex-1"
                />
                <Button variant="ghost" size="sm">
                  <Smile className="w-4 h-4" />
                </Button>
                <Button onClick={sendMessage} className="bg-red-600 hover:bg-red-700 text-white">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
