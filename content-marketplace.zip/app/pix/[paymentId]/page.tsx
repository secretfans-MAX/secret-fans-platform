"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Copy, CheckCircle, Clock, ArrowLeft, Play, RefreshCw } from "lucide-react"

// Mock PIX data
const mockPixData = {
  paymentId: "pix_abc123",
  amount: 25.0,
  pixCode:
    "00020126580014BR.GOV.BCB.PIX0136abcd1234efgh5678ijkl9012mnop3456520400005303986540025.005802BR5925CONTENTHUB PAGAMENTOS6009SAO PAULO62070503***6304ABCD",
  qrCodeUrl:
    "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICAgICAgPHJlY3Qgd2lkdGg9IjIwMCIgaGVpZ2h0PSIyMDAiIGZpbGw9IndoaXRlIi8+CiAgICAgIDx0ZXh0IHg9IjEwMCIgeT0iMTAwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTIiPlFSIENvZGUgUElYPC90ZXh0PgogICAgICA8dGV4dCB4PSIxMDAiIHk9IjEyMCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjgiPlIkIDI1LjAwPC90ZXh0PgogICAgPC9zdmc+",
  expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
  status: "pending",
}

export default function PixPaymentPage({ params }: { params: { paymentId: string } }) {
  const [copied, setCopied] = useState(false)
  const [timeLeft, setTimeLeft] = useState(30 * 60) // 30 minutes in seconds
  const [paymentStatus, setPaymentStatus] = useState("pending")

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    // Simulate payment status checking
    const statusCheck = setInterval(() => {
      // 10% chance of payment being completed each check
      if (Math.random() > 0.9 && paymentStatus === "pending") {
        setPaymentStatus("completed")
        clearInterval(statusCheck)
      }
    }, 5000)

    return () => clearInterval(statusCheck)
  }, [paymentStatus])

  const copyPixCode = async () => {
    try {
      await navigator.clipboard.writeText(mockPixData.pixCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Failed to copy PIX code:", err)
    }
  }

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  if (paymentStatus === "completed") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-6">
            <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Pagamento Confirmado!</h2>
            <p className="text-slate-600 dark:text-slate-400 mb-6">
              Seu PIX foi processado com sucesso. O conteúdo já está disponível.
            </p>
            <div className="space-y-3">
              <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                Acessar Conteúdo
              </Button>
              <Link href="/dashboard">
                <Button variant="outline" className="w-full bg-transparent">
                  Ir para Dashboard
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (timeLeft === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-6">
            <div className="w-16 h-16 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-8 h-8 text-red-600" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">PIX Expirado</h2>
            <p className="text-slate-600 dark:text-slate-400 mb-6">
              O código PIX expirou. Gere um novo código para continuar com o pagamento.
            </p>
            <div className="space-y-3">
              <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                Gerar Novo PIX
              </Button>
              <Link href="/explore">
                <Button variant="outline" className="w-full bg-transparent">
                  Voltar para Explorar
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/explore" className="flex items-center space-x-2 text-slate-600 hover:text-slate-900">
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar</span>
            </Link>
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Play className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-bold text-slate-900 dark:text-white">ContentHub</span>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Pagamento via PIX</h1>
            <p className="text-slate-600 dark:text-slate-300">
              Escaneie o QR Code ou copie o código PIX para finalizar o pagamento
            </p>
          </div>

          <div className="space-y-6">
            {/* Payment Status */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <Badge
                      variant="secondary"
                      className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                    >
                      <Clock className="w-3 h-3 mr-1" />
                      Aguardando Pagamento
                    </Badge>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-600">R$ {mockPixData.amount.toFixed(2)}</div>
                    <div className="text-sm text-slate-500">Expira em {formatTime(timeLeft)}</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* QR Code */}
            <Card>
              <CardHeader className="text-center">
                <CardTitle>Escaneie o QR Code</CardTitle>
                <CardDescription>Use o app do seu banco para escanear</CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <div className="inline-block p-4 bg-white rounded-lg shadow-sm">
                  <img
                    src={mockPixData.qrCodeUrl || "/placeholder.svg"}
                    alt="QR Code PIX"
                    className="w-48 h-48 mx-auto"
                  />
                </div>
                <p className="text-sm text-slate-500 mt-4">Abra o app do seu banco e escaneie o código acima</p>
              </CardContent>
            </Card>

            {/* PIX Code */}
            <Card>
              <CardHeader>
                <CardTitle>Ou copie o código PIX</CardTitle>
                <CardDescription>Cole no seu app bancário na opção PIX Copia e Cola</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-lg font-mono text-sm break-all">
                    {mockPixData.pixCode}
                  </div>
                  <Button onClick={copyPixCode} className="w-full" variant={copied ? "default" : "outline"}>
                    {copied ? (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Código Copiado!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-2" />
                        Copiar Código PIX
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Instructions */}
            <Card>
              <CardHeader>
                <CardTitle>Como pagar</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-semibold text-purple-600">1</span>
                    </div>
                    <p>Abra o app do seu banco ou carteira digital</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-semibold text-purple-600">2</span>
                    </div>
                    <p>Escolha a opção PIX e depois "Ler QR Code" ou "Copia e Cola"</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-semibold text-purple-600">3</span>
                    </div>
                    <p>Escaneie o QR Code ou cole o código PIX</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-semibold text-purple-600">4</span>
                    </div>
                    <p>Confirme o pagamento no seu app</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Auto-refresh notice */}
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2 text-sm text-slate-500">
                <RefreshCw className="w-4 h-4" />
                <span>Esta página será atualizada automaticamente após o pagamento</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
