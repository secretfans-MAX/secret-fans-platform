"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface User {
  id: string
  email: string
  name: string
  type: "creator" | "buyer"
  avatar?: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Check for existing session on mount
  useEffect(() => {
    const savedUser = localStorage.getItem("secretfans_user")
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    // Mock authentication - accept admin@admin.com with admin123
    if (email === "admin@admin.com" && password === "admin123") {
      const mockUser: User = {
        id: "1",
        email: "admin@admin.com",
        name: "Admin Creator",
        type: "creator",
        avatar: "/abstract-profile.png",
      }
      setUser(mockUser)
      localStorage.setItem("secretfans_user", JSON.stringify(mockUser))
      return true
    }

    // Also accept some test buyer accounts
    if (email === "buyer@test.com" && password === "test123") {
      const mockUser: User = {
        id: "2",
        email: "buyer@test.com",
        name: "Test Buyer",
        type: "buyer",
      }
      setUser(mockUser)
      localStorage.setItem("secretfans_user", JSON.stringify(mockUser))
      return true
    }

    return false
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("secretfans_user")
  }

  return <AuthContext.Provider value={{ user, login, logout, isLoading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
